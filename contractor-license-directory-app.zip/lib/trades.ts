export const STATUTORY_BOND_AMOUNT = 25000
export const STATUTORY_CITATIONS = "BPC § 7071.6 · SB 607"
export const DEFAULT_RENEWAL = "Every 2 years"

export const COVERAGE_OPTIONS = ["Surety Bond", "General Liability", "Workers Comp"] as const
export type Coverage = (typeof COVERAGE_OPTIONS)[number]

export type Requirement = {
  title: string
  detail?: string
  citation?: string
}

export type TradeEntry = {
  licenseClass: string
  name: string
  description: string
  bondAmount: number
  citation: string
  renewalCycle: string
  requirements: Requirement[]
}

export const TARGET_TRADES: Omit<TradeEntry, "requirements">[] = [
  {
    licenseClass: "B",
    name: "General Building Contractor",
    description:
      "Framing or construction of structures for shelter, housing, or enclosure, coordinating two or more unrelated trades.",
    bondAmount: STATUTORY_BOND_AMOUNT,
    citation: STATUTORY_CITATIONS,
    renewalCycle: DEFAULT_RENEWAL,
  },
  {
    licenseClass: "C-8",
    name: "Concrete Contractor",
    description: "Forming, pouring, placement, and finishing of concrete, including flatwork and structural elements.",
    bondAmount: STATUTORY_BOND_AMOUNT,
    citation: STATUTORY_CITATIONS,
    renewalCycle: DEFAULT_RENEWAL,
  },
  {
    licenseClass: "C-10",
    name: "Electrical Contractor",
    description: "Installation of electrical conductors and equipment that generate, transmit, or use electrical energy.",
    bondAmount: STATUTORY_BOND_AMOUNT,
    citation: STATUTORY_CITATIONS,
    renewalCycle: DEFAULT_RENEWAL,
  },
  {
    licenseClass: "C-20",
    name: "Warm-Air Heating, Ventilating & Air-Conditioning (HVAC)",
    description: "Fabrication and installation of heating, ventilating, and air-conditioning systems and ductwork.",
    bondAmount: STATUTORY_BOND_AMOUNT,
    citation: STATUTORY_CITATIONS,
    renewalCycle: DEFAULT_RENEWAL,
  },
  {
    licenseClass: "C-36",
    name: "Plumbing Contractor",
    description: "Installation of water, gas, and waste systems, fixtures, and related piping in structures.",
    bondAmount: STATUTORY_BOND_AMOUNT,
    citation: STATUTORY_CITATIONS,
    renewalCycle: DEFAULT_RENEWAL,
  },
  {
    licenseClass: "C-39",
    name: "Roofing Contractor",
    description: "Installation of roofing materials that waterproof and weatherproof structures.",
    bondAmount: STATUTORY_BOND_AMOUNT,
    citation: STATUTORY_CITATIONS,
    renewalCycle: DEFAULT_RENEWAL,
  },
]

export function normalizeClass(value: string | undefined): string {
  if (!value) return ""
  const cleaned = value.toUpperCase().replace(/[\s_]/g, "").replace(/^CLASS/, "")
  const match = cleaned.match(/^([A-Z])-?0*(\d+)?/)
  if (!match) return cleaned
  return match[2] ? `${match[1]}-${match[2]}` : match[1]
}

export function tradeSlug(licenseClass: string) {
  return `class-${licenseClass.toLowerCase()}`
}

export function formatCurrency(amount: number) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(amount)
}
