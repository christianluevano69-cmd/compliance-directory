import "server-only"
import { getSupabase } from "@/lib/supabase"
import {
  STATUTORY_BOND_AMOUNT,
  STATUTORY_CITATIONS,
  TARGET_TRADES,
  normalizeClass,
  type Requirement,
  type TradeEntry,
} from "@/lib/trades"

type Row = Record<string, unknown>

function pick(row: Row, keys: string[]): unknown {
  for (const key of keys) {
    const value = row[key]
    if (value !== null && value !== undefined && value !== "") return value
  }
  return undefined
}

function asString(value: unknown): string | undefined {
  if (value === undefined || value === null) return undefined
  if (Array.isArray(value)) return value.map(String).join(" · ")
  return String(value)
}

function asNumber(value: unknown): number | undefined {
  if (typeof value === "number") return value
  if (typeof value === "string") {
    const n = Number(value.replace(/[^0-9.]/g, ""))
    return Number.isFinite(n) && n > 0 ? n : undefined
  }
  return undefined
}

function formatMonths(months: number | undefined): string | undefined {
  if (!months) return undefined
  if (months % 12 === 0) return months === 12 ? "Every year" : `Every ${months / 12} years`
  return `Every ${months} months`
}

const usd = (n: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n)

function toRequirements(r: Row): Requirement[] {
  const citation = asString(pick(r, ["statutory_reference", "statutory_citation", "citation"]))
  const items: Requirement[] = []
  const bond = asNumber(r.bond_amount)
  if (r.bond_required === true) {
    items.push({ title: "Contractor license bond", detail: bond ? `${usd(bond)} surety bond on file with the CSLB` : undefined, citation })
  }
  const liability = asNumber(r.insurance_min_liability)
  if (liability) items.push({ title: "General liability", detail: `${usd(liability)} minimum per occurrence` })
  if (r.workers_comp_required === true) {
    items.push({ title: "Workers' compensation", detail: "Certificate or exemption required on file" })
  }
  const fee = asNumber(r.application_fee)
  if (fee) items.push({ title: "Application fee", detail: usd(fee) })
  if (r.exam_required === true) items.push({ title: "Licensing exam", detail: "Law & business plus trade exam" })
  if (items.length === 0) {
    items.push({
      title: asString(pick(r, ["requirement", "title", "name", "type"])) ?? "Compliance requirement",
      detail: asString(pick(r, ["description", "details", "notes"])),
      citation,
    })
  }
  return items
}

const CLASS_KEYS = ["license_class", "classification", "class_code", "code", "trade_code", "class"]
const NAME_KEYS = ["name", "trade_name", "title", "classification_name", "label"]

export type DirectoryResult = {
  trades: TradeEntry[]
  source: "supabase" | "fallback"
}

export async function getDirectory(): Promise<DirectoryResult> {
  const supabase = getSupabase()
  const fallback: DirectoryResult = {
    source: "fallback",
    trades: TARGET_TRADES.map((t) => ({ ...t, requirements: [] })),
  }
  if (!supabase) return fallback

  try {
    const [tradesRes, reqRes] = await Promise.all([
      supabase.from("trades").select("*"),
      supabase.from("compliance_requirements").select("*"),
    ])

    if (tradesRes.error) {
      console.error("[directory] trades query failed:", tradesRes.error.message)
      return fallback
    }
    if (reqRes.error) {
      console.error("[directory] compliance_requirements query failed:", reqRes.error.message)
    }

    const tradeRows = (tradesRes.data ?? []) as Row[]
    const reqRows = (reqRes.data ?? []) as Row[]
    if (tradeRows.length === 0) return fallback

    const trades: TradeEntry[] = TARGET_TRADES.map((target) => {
      const row = tradeRows.find(
        (r) => normalizeClass(asString(pick(r, CLASS_KEYS))) === normalizeClass(target.licenseClass),
      )
      if (!row) return { ...target, requirements: [] }

      const tradeId = row.id
      const related = reqRows.filter((req) => {
        if (tradeId !== undefined && req.trade_id !== undefined) return req.trade_id === tradeId
        return (
          normalizeClass(asString(pick(req, ["license_class", "trade_class", "classification", "trade_code"]))) ===
          normalizeClass(target.licenseClass)
        )
      })

      const bondFromReqs = related
        .map((r) => asNumber(pick(r, ["bond_amount", "amount"])))
        .find((n) => n !== undefined)
      const citationFromReqs = related
        .map((r) =>
          asString(pick(r, ["statutory_reference", "statutory_citation", "citation", "statute", "legal_citation"])),
        )
        .find(Boolean)
      const renewalFromReqs =
        related.map((r) => formatMonths(asNumber(r.renewal_cycle_months))).find(Boolean) ??
        related
          .map((r) => asString(pick(r, ["renewal_cycle", "renewal_period", "renewal_frequency", "renewal"])))
          .find(Boolean)

      return {
        licenseClass: target.licenseClass,
        name: asString(pick(row, NAME_KEYS)) ?? target.name,
        description: asString(pick(row, ["description", "summary", "scope"])) ?? target.description,
        bondAmount:
          asNumber(pick(row, ["bond_amount", "surety_bond_amount"])) ?? bondFromReqs ?? STATUTORY_BOND_AMOUNT,
        citation: asString(pick(row, ["statutory_citation", "citation"])) ?? citationFromReqs ?? STATUTORY_CITATIONS,
        renewalCycle: asString(pick(row, ["renewal_cycle", "renewal_period"])) ?? renewalFromReqs ?? target.renewalCycle,
        requirements: related.flatMap(toRequirements),
      }
    })

    return { trades, source: "supabase" }
  } catch (error) {
    console.error("[directory] Supabase unreachable:", error instanceof Error ? error.message : error)
    return fallback
  }
}
