"use server"

import { getSupabase } from "@/lib/supabase"
import { COVERAGE_OPTIONS, TARGET_TRADES, type Coverage } from "@/lib/trades"

export type LeadState = {
  status: "idle" | "success" | "error"
  message?: string
  fieldErrors?: Partial<Record<"contractor_name" | "email" | "phone" | "trade_class" | "coverage_needed", string>>
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/
const VALID_CLASSES = new Set(TARGET_TRADES.map((t) => t.licenseClass))

export async function submitLead(_prev: LeadState, formData: FormData): Promise<LeadState> {
  const contractorName = String(formData.get("contractor_name") ?? "").trim().slice(0, 160)
  const email = String(formData.get("email") ?? "").trim().toLowerCase().slice(0, 254)
  const phoneRaw = String(formData.get("phone") ?? "").trim().slice(0, 32)
  const phoneDigits = phoneRaw.replace(/\D/g, "")
  const tradeClass = String(formData.get("trade_class") ?? "").trim()
  const coverage = formData
    .getAll("coverage_needed")
    .map(String)
    .filter((c): c is Coverage => (COVERAGE_OPTIONS as readonly string[]).includes(c))

  // Honeypot: bots fill hidden fields, humans don't.
  if (String(formData.get("company_website") ?? "").length > 0) {
    return { status: "success", message: "Thanks — a licensing specialist will reach out shortly." }
  }

  const fieldErrors: LeadState["fieldErrors"] = {}
  if (contractorName.length < 2) fieldErrors.contractor_name = "Enter your name or business name."
  if (!EMAIL_RE.test(email)) fieldErrors.email = "Enter a valid email address."
  if (phoneDigits.length < 10 || phoneDigits.length > 15) fieldErrors.phone = "Enter a valid phone number."
  if (!VALID_CLASSES.has(tradeClass)) fieldErrors.trade_class = "Select a trade class."
  if (coverage.length === 0) fieldErrors.coverage_needed = "Select at least one coverage type."

  if (Object.keys(fieldErrors).length > 0) {
    return { status: "error", message: "Please fix the highlighted fields.", fieldErrors }
  }

  const supabase = getSupabase()
  if (!supabase) {
    return { status: "error", message: "Lead capture is temporarily unavailable. Please try again later." }
  }

  const { data: tradeRow, error: tradeError } = await supabase
    .from("trades")
    .select("id")
    .eq("trade_code", tradeClass)
    .maybeSingle()

  if (tradeError || !tradeRow) {
    console.error("[leads] trade lookup failed:", tradeClass, tradeError?.message)
    return { status: "error", message: "We couldn't submit your request. Please try again in a moment." }
  }

  const { error } = await supabase.from("leads").insert({
    contractor_name: contractorName,
    email,
    phone: phoneRaw,
    trade_id: tradeRow.id,
    coverage_needed: coverage,
  })

  if (error) {
    console.error("[leads] insert failed:", error.code, error.message)
    return { status: "error", message: "We couldn't submit your request. Please try again in a moment." }
  }

  return { status: "success", message: "Request received. A licensing specialist will contact you within 1 business day." }
}
