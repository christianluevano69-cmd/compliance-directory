import Link from "next/link"
import { Hero } from "@/components/hero"
import { RequirementsSection } from "@/components/requirements-section"
import { SiteHeader } from "@/components/site-header"
import { TradeCard } from "@/components/trade-card"
import { getDirectory } from "@/lib/directory"
import { tradeSlug } from "@/lib/trades"

export const revalidate = 3600

export default async function Page() {
  const { trades, source } = await getDirectory()

  return (
    <>
      <SiteHeader />
      <main>
        <Hero />

        <section id="trades" aria-labelledby="trades-title" className="scroll-mt-16">
          <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 md:py-20">
            <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
              <div className="max-w-2xl">
                <h2 id="trades-title" className="text-balance text-2xl font-semibold tracking-tight sm:text-3xl">
                  License classifications &amp; bond requirements
                </h2>
                <p className="mt-3 text-muted-foreground">
                  Choose your CSLB classification to see its bond amount, statute, and renewal cycle, then request a
                  quote.
                </p>
              </div>
              <nav aria-label="Jump to trade" className="flex flex-wrap gap-2">
                {trades.map((t) => (
                  <Link
                    key={t.licenseClass}
                    href={`#${tradeSlug(t.licenseClass)}`}
                    className="rounded-md border bg-card px-3 py-1.5 font-mono text-xs font-medium hover:bg-muted"
                  >
                    {t.licenseClass}
                  </Link>
                ))}
              </nav>
            </div>

            {source === "fallback" && (
              <p className="mt-6 rounded-md border border-dashed px-4 py-3 text-xs text-muted-foreground">
                Showing statutory defaults. Live directory data is temporarily unavailable.
              </p>
            )}

            <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {trades.map((trade) => (
                <TradeCard key={trade.licenseClass} trade={trade} />
              ))}
            </div>
          </div>
        </section>

        <RequirementsSection />
      </main>
      <footer className="border-t">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-8 text-xs text-muted-foreground sm:flex-row sm:justify-between sm:px-6">
          <p>{`© ${new Date().getFullYear()} California Contractor Bond Directory`}</p>
          <p>Not affiliated with the Contractors State License Board.</p>
        </div>
      </footer>
    </>
  )
}
