import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { IBM_Plex_Mono, Inter } from 'next/font/google'
import { ThemeProvider } from 'next-themes'
import './globals.css'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })
const plexMono = IBM_Plex_Mono({ subsets: ['latin'], weight: ['400', '500', '600'], variable: '--font-plex-mono' })

export const metadata: Metadata = {
  title: 'California Contractor License & Surety Bond Directory | $25,000 CSLB Bond',
  description:
    'California contractor license bond requirements by trade: General Building (B), Concrete (C-8), Electrical (C-10), HVAC (C-20), Plumbing (C-36), and Roofing (C-39). $25,000 bond under BPC § 7071.6 and SB 607.',
  keywords: [
    'California contractor bond',
    'CSLB bond',
    '$25,000 contractor bond',
    'BPC 7071.6',
    'SB 607',
    'contractor license bond',
  ],
  generator: 'v0.app',
  openGraph: {
    title: 'California Contractor License & Surety Bond Directory',
    description: 'Bond amounts, statutes, and renewal cycles for California contractor classifications.',
    type: 'website',
  },
  icons: {
    icon: [
      { url: '/icon-light-32x32.png', media: '(prefers-color-scheme: light)' },
      { url: '/icon-dark-32x32.png', media: '(prefers-color-scheme: dark)' },
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'light dark',
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#f9fafb' },
    { media: '(prefers-color-scheme: dark)', color: '#10151f' },
  ],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning className={`${inter.variable} ${plexMono.variable}`}>
      <body className="antialiased">
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          {children}
        </ThemeProvider>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
