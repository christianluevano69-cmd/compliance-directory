"use client"

import { useActionState, useId } from "react"
import { CheckCircle2, Loader2 } from "lucide-react"
import { submitLead, type LeadState } from "@/app/actions"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { COVERAGE_OPTIONS, TARGET_TRADES } from "@/lib/trades"
import { cn } from "@/lib/utils"

const initialState: LeadState = { status: "idle" }

export function LeadForm({ defaultTradeClass }: { defaultTradeClass: string }) {
  const [state, formAction, pending] = useActionState(submitLead, initialState)
  const id = useId()
  const errors = state.fieldErrors ?? {}

  if (state.status === "success") {
    return (
      <div
        role="status"
        className="flex items-start gap-3 rounded-lg border border-success/30 bg-success/10 p-4 text-sm"
      >
        <CheckCircle2 className="mt-0.5 size-5 shrink-0 text-success" aria-hidden="true" />
        <p className="text-foreground">{state.message}</p>
      </div>
    )
  }

  return (
    <form action={formAction} noValidate className="flex flex-col gap-4">
      <div className="hidden" aria-hidden="true">
        <label htmlFor={`${id}-website`}>Company website</label>
        <input id={`${id}-website`} name="company_website" tabIndex={-1} autoComplete="off" />
      </div>

      <Field id={`${id}-name`} label="Contractor name" error={errors.contractor_name}>
        <Input
          id={`${id}-name`}
          name="contractor_name"
          autoComplete="organization"
          placeholder="Acme Builders Inc."
          required
          aria-invalid={Boolean(errors.contractor_name)}
          aria-describedby={errors.contractor_name ? `${id}-name-error` : undefined}
        />
      </Field>

      <div className="grid gap-4 sm:grid-cols-2">
        <Field id={`${id}-email`} label="Email" error={errors.email}>
          <Input
            id={`${id}-email`}
            name="email"
            type="email"
            autoComplete="email"
            placeholder="you@company.com"
            required
            aria-invalid={Boolean(errors.email)}
            aria-describedby={errors.email ? `${id}-email-error` : undefined}
          />
        </Field>
        <Field id={`${id}-phone`} label="Phone number" error={errors.phone}>
          <Input
            id={`${id}-phone`}
            name="phone"
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            placeholder="(555) 555-0123"
            required
            aria-invalid={Boolean(errors.phone)}
            aria-describedby={errors.phone ? `${id}-phone-error` : undefined}
          />
        </Field>
      </div>

      <Field id={`${id}-class`} label="Trade class" error={errors.trade_class}>
        <select
          id={`${id}-class`}
          name="trade_class"
          defaultValue={defaultTradeClass}
          aria-invalid={Boolean(errors.trade_class)}
          className="h-9 w-full rounded-md border border-input bg-transparent px-2.5 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 dark:bg-input/30"
        >
          {TARGET_TRADES.map((t) => (
            <option key={t.licenseClass} value={t.licenseClass}>
              {`${t.licenseClass} — ${t.name}`}
            </option>
          ))}
        </select>
      </Field>

      <fieldset
        className="flex flex-col gap-2"
        aria-describedby={errors.coverage_needed ? `${id}-coverage-error` : undefined}
      >
        <legend className="mb-2 text-sm font-medium">Coverage needed</legend>
        <div className="flex flex-wrap gap-2">
          {COVERAGE_OPTIONS.map((option, i) => (
            <label
              key={option}
              className={cn(
                "flex cursor-pointer items-center gap-2 rounded-md border border-input px-3 py-2 text-sm transition-colors",
                "hover:bg-muted has-[:checked]:border-primary has-[:checked]:bg-primary/10 has-[:focus-visible]:ring-3 has-[:focus-visible]:ring-ring/50",
              )}
            >
              <input
                type="checkbox"
                name="coverage_needed"
                value={option}
                defaultChecked={i === 0}
                className="size-4 accent-primary"
              />
              {option}
            </label>
          ))}
        </div>
        {errors.coverage_needed && (
          <p id={`${id}-coverage-error`} className="text-xs text-destructive">
            {errors.coverage_needed}
          </p>
        )}
      </fieldset>

      {state.status === "error" && state.message && (
        <p role="alert" className="text-sm text-destructive">
          {state.message}
        </p>
      )}

      <Button
        type="submit"
        size="lg"
        disabled={pending}
        className="w-full bg-accent text-accent-foreground hover:bg-accent/90"
      >
        {pending ? (
          <>
            <Loader2 className="size-4 animate-spin" aria-hidden="true" />
            Submitting…
          </>
        ) : (
          "Get my free bond quote"
        )}
      </Button>
      <p className="text-center text-xs text-muted-foreground">
        No obligation. Your information is only used to prepare your quote.
      </p>
    </form>
  )
}

function Field({
  id,
  label,
  error,
  children,
}: {
  id: string
  label: string
  error?: string
  children: React.ReactNode
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label htmlFor={id}>{label}</Label>
      {children}
      {error && (
        <p id={`${id}-error`} className="text-xs text-destructive">
          {error}
        </p>
      )}
    </div>
  )
}
