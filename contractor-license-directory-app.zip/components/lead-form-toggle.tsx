"use client"

import { useId, useState } from "react"
import { ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { LeadForm } from "@/components/lead-form"
import { cn } from "@/lib/utils"

export function LeadFormToggle({ tradeClass, tradeName }: { tradeClass: string; tradeName: string }) {
  const [open, setOpen] = useState(false)
  const panelId = useId()

  return (
    <div className="flex flex-col gap-4">
      <Button
        type="button"
        size="lg"
        variant={open ? "outline" : "default"}
        className="w-full justify-between"
        aria-expanded={open}
        aria-controls={panelId}
        onClick={() => setOpen((v) => !v)}
      >
        <span>{open ? "Hide quote request" : `Get a ${tradeClass} bond quote`}</span>
        <ChevronDown className={cn("size-4 transition-transform", open && "rotate-180")} aria-hidden="true" />
      </Button>
      <div id={panelId} hidden={!open} aria-label={`Quote request for ${tradeName}`} role="region">
        {open && <LeadForm defaultTradeClass={tradeClass} />}
      </div>
    </div>
  )
}
