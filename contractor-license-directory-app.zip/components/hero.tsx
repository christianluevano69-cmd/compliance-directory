import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { formatCurrency, STATUTORY_BOND_AMOUNT } from "@/lib/trades"

const STATS = [
  { label: "Statutory contractor bond", value: formatCurrency(STATUTORY_BOND_AMOUNT) },
  { label: "Governing statute", value: "BPC § 7071.6" },
  { label: "Enacted by", value: "SB 607" },
  { label: "Active license renewal", value: "Every 2 years" },
]

export function Hero() {
  return (
    <section aria-labelledby="hero-title" className="border-b bg-muted/40">
      <div className="mx-auto flex max-w-6xl flex-col gap-10 px-4 py-14 sm:px-6 md:py-20">
        <div className="flex max-w-3xl flex-col gap-5">
          <p className="w-fit rounded-full border bg-background px-3 py-1 text-xs font-medium text-muted-foreground">
            Updated for 2026 CSLB bond requirements
          </p>
          <h1 id="hero-title" className="text-balance text-3xl font-semibold tracking-tight sm:text-5xl">
            California Contractor License &amp; Surety Bond Directory
          </h1>
          <p className="text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
            {
              "Every licensed California contractor must file a $25,000 contractor's bond with the CSLB. Check the requirements for your trade classification and request a same-day bond quote."
            }
          </p>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Button size="lg" nativeButton={false} render={<Link href="#trades" />}>
              Find your trade
              <ArrowRight className="size-4" aria-hidden="true" />
            </Button>
            <Button size="lg" variant="outline" nativeButton={false} render={<Link href="#requirements" />}>
              Read the requirements
            </Button>
          </div>
        </div>

        <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-xl border bg-border md:grid-cols-4">
          {STATS.map((stat) => (
            <div key={stat.label} className="flex flex-col gap-1 bg-card p-4 sm:p-5">
              <dt className="text-xs text-muted-foreground">{stat.label}</dt>
              <dd className="font-mono text-lg font-semibold sm:text-2xl">{stat.value}</dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  )
}
