import { CalendarClock, FileText, ShieldCheck } from "lucide-react"
import { LeadFormToggle } from "@/components/lead-form-toggle"
import { formatCurrency, tradeSlug, type TradeEntry } from "@/lib/trades"

export function TradeCard({ trade }: { trade: TradeEntry }) {
  const slug = tradeSlug(trade.licenseClass)

  return (
    <article
      id={slug}
      aria-labelledby={`${slug}-title`}
      className="flex scroll-mt-24 flex-col overflow-hidden rounded-xl border bg-card text-card-foreground shadow-sm"
    >
      <header className="flex items-start gap-4 p-5 pb-4">
        <div
          className="flex size-12 shrink-0 items-center justify-center rounded-lg bg-primary font-mono text-sm font-semibold text-primary-foreground"
          aria-hidden="true"
        >
          {trade.licenseClass}
        </div>
        <div className="min-w-0">
          <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            {`CSLB Class ${trade.licenseClass}`}
          </p>
          <h3 id={`${slug}-title`} className="text-pretty text-lg font-semibold leading-snug">
            {trade.name}
          </h3>
        </div>
      </header>

      <p className="px-5 text-sm leading-relaxed text-muted-foreground">{trade.description}</p>

      <dl className="mx-5 mt-5 grid grid-cols-1 divide-y rounded-lg border bg-muted/40 text-sm">
        <div className="flex items-center justify-between gap-4 p-3">
          <dt className="flex items-center gap-2 text-muted-foreground">
            <ShieldCheck className="size-4 text-primary" aria-hidden="true" />
            Contractor bond
          </dt>
          <dd className="font-mono text-base font-semibold">{formatCurrency(trade.bondAmount)}</dd>
        </div>
        <div className="flex items-center justify-between gap-4 p-3">
          <dt className="flex items-center gap-2 text-muted-foreground">
            <FileText className="size-4 text-primary" aria-hidden="true" />
            Statute
          </dt>
          <dd className="text-right font-mono text-xs font-medium">{trade.citation}</dd>
        </div>
        <div className="flex items-center justify-between gap-4 p-3">
          <dt className="flex items-center gap-2 text-muted-foreground">
            <CalendarClock className="size-4 text-primary" aria-hidden="true" />
            License renewal
          </dt>
          <dd className="text-right font-medium">{trade.renewalCycle}</dd>
        </div>
      </dl>

      {trade.requirements.length > 0 && (
        <div className="px-5 pt-5">
          <h4 className="text-sm font-semibold">Compliance requirements</h4>
          <ul className="mt-2 flex flex-col gap-2">
            {trade.requirements.map((req, i) => (
              <li key={`${req.title}-${i}`} className="flex gap-2 text-sm">
                <span className="mt-2 size-1.5 shrink-0 rounded-full bg-accent" aria-hidden="true" />
                <span>
                  <span className="font-medium">{req.title}</span>
                  {req.detail && <span className="text-muted-foreground">{` — ${req.detail}`}</span>}
                  {req.citation && (
                    <span className="ml-1 font-mono text-xs text-muted-foreground">{`(${req.citation})`}</span>
                  )}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="mt-auto p-5 pt-5">
        <LeadFormToggle tradeClass={trade.licenseClass} tradeName={trade.name} />
      </div>
    </article>
  )
}
