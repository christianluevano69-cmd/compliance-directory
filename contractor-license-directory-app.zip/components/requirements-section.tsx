import { Gavel, RefreshCcw, Scale } from "lucide-react"

const ITEMS = [
  {
    icon: Scale,
    title: "$25,000 contractor bond",
    citation: "BPC § 7071.6",
    body: "Before a license is issued, reactivated, reinstated, or renewed, every applicant or licensee must have on file a contractor's bond in the sum of $25,000.",
  },
  {
    icon: Gavel,
    title: "SB 607 increase",
    citation: "SB 607 (2021)",
    body: "Senate Bill 607 raised the contractor's bond from $15,000 to $25,000, effective January 1, 2023, for all license classifications.",
  },
  {
    icon: RefreshCcw,
    title: "Renewal cycle",
    citation: "BPC § 7140",
    body: "Active contractor licenses renew every two years. Your bond must remain continuously in force; a lapse suspends the license automatically.",
  },
]

export function RequirementsSection() {
  return (
    <section id="requirements" aria-labelledby="requirements-title" className="scroll-mt-20 border-t bg-muted/40">
      <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 md:py-20">
        <div className="max-w-2xl">
          <h2 id="requirements-title" className="text-balance text-2xl font-semibold tracking-tight sm:text-3xl">
            Statutory bond requirements for California contractors
          </h2>
          <p className="mt-3 text-muted-foreground">
            The same bond obligation applies to every classification below. Workers&apos; compensation and general
            liability requirements vary by trade and payroll.
          </p>
        </div>
        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {ITEMS.map((item) => (
            <div key={item.title} className="flex flex-col gap-3 rounded-xl border bg-card p-6">
              <item.icon className="size-5 text-primary" aria-hidden="true" />
              <h3 className="font-semibold">{item.title}</h3>
              <p className="font-mono text-xs text-muted-foreground">{item.citation}</p>
              <p className="text-sm leading-relaxed text-muted-foreground">{item.body}</p>
            </div>
          ))}
        </div>
        <p className="mt-8 text-xs text-muted-foreground">
          This directory is for informational purposes and is not legal advice. Confirm current requirements with the
          Contractors State License Board (CSLB).
        </p>
      </div>
    </section>
  )
}
