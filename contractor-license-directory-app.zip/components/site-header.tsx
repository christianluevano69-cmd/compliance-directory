import Link from "next/link"
import { Landmark } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b bg-background/85 backdrop-blur supports-[backdrop-filter]:bg-background/70">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <span className="flex size-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <Landmark className="size-4" aria-hidden="true" />
          </span>
          <span className="text-sm sm:text-base">CA Contractor Bond Directory</span>
        </Link>
        <nav aria-label="Primary" className="flex items-center gap-1">
          <Link
            href="#trades"
            className="hidden rounded-md px-3 py-2 text-sm text-muted-foreground hover:text-foreground sm:inline-flex"
          >
            Trades
          </Link>
          <Link
            href="#requirements"
            className="hidden rounded-md px-3 py-2 text-sm text-muted-foreground hover:text-foreground sm:inline-flex"
          >
            Requirements
          </Link>
          <ThemeToggle />
        </nav>
      </div>
    </header>
  )
}
